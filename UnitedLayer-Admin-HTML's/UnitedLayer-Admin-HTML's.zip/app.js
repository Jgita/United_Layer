var app = angular.module('unitedLayer', [
    'ui.router',
    'ngSanitize',
    'mwl.calendar',
    'ui.bootstrap',
    'ngAnimate',
    'ngScrollbars',
    'infinite-scroll',
    'angularSpinner',
    'chart.js',
    'cgBusy',
    'daterangepicker',
    'ui.bootstrap.datetimepicker',
    'ui.dateTimeInput'
]);