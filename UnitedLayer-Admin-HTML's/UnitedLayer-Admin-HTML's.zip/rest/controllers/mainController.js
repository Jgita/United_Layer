app.controller('mainController', function($scope, $state) {
    $scope.mainMessage = "this is coming from mainController"

});