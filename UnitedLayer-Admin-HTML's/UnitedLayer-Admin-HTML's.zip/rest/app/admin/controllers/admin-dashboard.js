app.controller('admin-dashboard', function($scope) {
    console.log('admin-dashboard')
})