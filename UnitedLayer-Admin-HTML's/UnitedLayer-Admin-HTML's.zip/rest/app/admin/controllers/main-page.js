app.controller('main-page', function($scope, $state, $rootScope) {
    console.log('main-page')
        // $state.go('home.server.organizations.companyTab.servers');
})